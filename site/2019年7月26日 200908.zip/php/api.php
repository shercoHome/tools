<?php
if (is_array($_POST)&&count($_POST)>0) {
    $info=array();
    if (isset($_POST["searchWord"])) {
        if (strlen($_POST["searchWord"])>0) {
            $info["searchWord"]=trim($_POST['searchWord']);
        }
    }
    if (isset($_POST["searchPercent"])) {
        if (strlen($_POST["searchPercent"])>0) {
            $info["searchPercent"]=trim($_POST['searchPercent']);
        }
    }
    if (isset($_POST["needCheck"])) {
        if (strlen($_POST["needCheck"])>0) {
            $info["needCheck"]=trim($_POST['needCheck']);
        }
    }

    if (isset($_POST["type"])) {
        if (strlen($_POST["type"])>0) {
            $type=trim($_POST['type']);

            switch ($type) {
                case "checkBaiduKeyWord":
                require_once "class.checkBaiduKeyWord.php";
                $checkBaiduKeyWord=new checkBaiduKeyWord();

               // var_dump($info );
                $result =  $checkBaiduKeyWord->check($info);
               // var_dump($result );
               echo json_encode($result);
                break;
                case "GetBaiduRelatedSearch":
                require_once "class.GetBaiduRelatedSearch.php";
                $GetBaiduRelatedSearch=new GetBaiduRelatedSearch();
                $result =  $GetBaiduRelatedSearch->get($info);

                echo json_encode($result);
                break;

            }
        }
    }
}
